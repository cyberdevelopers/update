﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace okeyim
{
    class konum
    {
        tas konumTas;
        public konum()
        {
            konumTas = null;
        }

        public tas KonumTas{
            get { return konumTas; }
            set { konumTas = value; }
          }
       
        

    }
}
